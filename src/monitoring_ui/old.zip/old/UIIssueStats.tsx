import { useObserver } from "mobx-react-lite";
import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Typography from "@material-ui/core/Typography";
import { UIIssueStatsRow } from "./UIIssueStatsRow";
import debugjs from "debug";
import { colors } from "./UIRunStatus";
import { GlobalUIState } from "./RunStatus";

const debugRender = debugjs("render");

const useStyles = makeStyles({
    table: {
        minWidth: 900,
    },
    filterTextField: {
        marginLeft: "16px",
        width: "900px",
    },
    typographyStylesFooter: {
        margin: "16px",
        width: "100%",
    },
    stepColumn: {
        width: "1000px",
    },
});

const parseStatsToProjectArray = (stats: any) => {
    if (!stats) {
        return [];
    }

    if (stats.length == 0) {
        return [];
    }
    let result = [];

    let projects = [];

    outerLoop: for (let i of stats) {
        //проверяем, есть ли такой проект
        for (let currPrName of projects) {
            if (i.project == currPrName) {
                // изменяем progress
                // return food;
                for (let currProject of result) {
                    if (currProject.project === i.project) {
                        let jiraCount = i.stage == "01_jira" ? i.issueCount : 0;
                        let transformCount = i.stage == "02_transform" ? i.issueCount : 0;
                        let dbCount = i.stage == "03_db" ? i.issueCount : 0;
                        let succededCount = i.stage == "99_succeded" ? i.issueCount : 0;

                        for (let progressLine of currProject.Pprogress) {
                            if (i.stage === progressLine.stage) {
                                progressLine.progress += i.issueCount;
                                break;
                            }
                        }

                        currProject.onJira += jiraCount;
                        currProject.onTransform += transformCount;
                        currProject.onDB += dbCount;
                        currProject.succeded += succededCount;

                        currProject.total += i.issueCount;

                        continue outerLoop;
                    }
                }
            }
        }

        // не нашли проекта, создаем его!
        projects.push(i.project);
        let jiraCount = i.stage == "01_jira" ? i.issueCount : 0;
        let transformCount = i.stage == "02_transform" ? i.issueCount : 0;
        let dbCount = i.stage == "03_db" ? i.issueCount : 0;
        let succededCount = i.stage == "99_succeded" ? i.issueCount : 0;

        let localResult = {
            project: i.project,
            Pprogress: [
                { progress: jiraCount, color: colors.blue, stage: "01_jira" },
                { progress: transformCount, color: colors.pink, stage: "02_transform" },
                { progress: dbCount, color: colors.yellow, stage: "03_db" },
                { progress: succededCount, color: colors.green, stage: "99_succeded" },
            ],
            onJira: jiraCount,
            onTransform: transformCount,
            onDB: dbCount,
            succeded: succededCount,
            total: i.issueCount, /// DONT FORGET
        };
        result.push(localResult);
    }

    return result;
};

const parseStatsToAllStatsArray = (stats: any) => {
    if (!stats) {
        return [];
    }

    if (stats.length == 0) {
        return [];
    }

    let result = [];

    let localResult = {
        project: "all",
        Pprogress: [
            { progress: 0, color: colors.blue, stage: "01_jira" },
            { progress: 0, color: colors.pink, stage: "02_transform" },
            { progress: 0, color: colors.yellow, stage: "03_db" },
            { progress: 0, color: colors.green, stage: "99_succeded" },
        ],
        onJira: 0,
        onTransform: 0,
        onDB: 0,
        succeded: 0,
        total: 0, /// DONT FORGET
    };

    for (let i of stats) {
        // ALL
        let jiraCount = i.stage == "01_jira" ? i.issueCount : 0;
        let transformCount = i.stage == "02_transform" ? i.issueCount : 0;
        let dbCount = i.stage == "03_db" ? i.issueCount : 0;
        let succeded = i.stage == "99_succeded" ? i.issueCount : 0;

        //добавляем изменения
        localResult.Pprogress[0].progress += jiraCount;
        localResult.Pprogress[1].progress += transformCount;
        localResult.Pprogress[2].progress += dbCount;
        localResult.Pprogress[3].progress += succeded;

        localResult.onJira += jiraCount;
        localResult.onTransform += transformCount;
        localResult.onDB += dbCount;
        localResult.succeded += succeded;

        localResult.total += i.issueCount;
    }
    result.push(localResult);

    return result;
};

export const UIIssueStats: React.FC<{ issueStats: any; globalUIState: GlobalUIState }> = ({
    issueStats,
    globalUIState,
}) => {
    const classes = useStyles();
    debugRender("UIIssueStats");

    let statsProgress: any;
    if (globalUIState.issue_stats_checkProjects && !globalUIState.issue_stats_checkAll) {
        statsProgress = parseStatsToProjectArray(issueStats.stats);
    } else {
        statsProgress = parseStatsToAllStatsArray(issueStats.stats);
    }

    return useObserver(() => (
        <>
            <Table className={classes.table} size="small">
                <TableHead>
                    <TableRow>
                        {globalUIState.issue_stats_checkProjects && !globalUIState.issue_stats_checkAll ? (
                            <>
                                <TableCell>project</TableCell>
                                <TableCell style={{ minWidth: 350 }}>progress</TableCell>
                                <TableCell>onJira</TableCell>
                                <TableCell>onTransform</TableCell>
                                <TableCell>onDB</TableCell>
                                <TableCell>succeded</TableCell>
                                <TableCell>total</TableCell>
                            </>
                        ) : (
                            <>
                                <TableCell style={{ minWidth: 350 }}>progress</TableCell>
                                <TableCell>onJira</TableCell>
                                <TableCell>onTransform</TableCell>
                                <TableCell>onDB</TableCell>
                                <TableCell>succeded</TableCell>
                                <TableCell>total</TableCell>
                            </>
                        )}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {!issueStats.error ? (
                        statsProgress
                            .filter((currProject: any) => {
                                return (
                                    !globalUIState.logsFilter ||
                                    !globalUIState.logsFilter.trim().length ||
                                    currProject.jsonUpper.includes(globalUIState.logsFilter.trim().toUpperCase())
                                );
                            })
                            .map((currData: any) => (
                                <UIIssueStatsRow
                                    key={`${JSON.stringify(currData.Pprogress)}`}
                                    data={currData}
                                    globalUIState={globalUIState}
                                />
                            ))
                    ) : (
                        <TableRow>
                            {globalUIState.issue_stats_checkProjects && !globalUIState.issue_stats_checkAll ? (
                                <>
                                    <TableCell />
                                    <TableCell>{issueStats.error}</TableCell>
                                </>
                            ) : (
                                <>
                                    <TableCell>{issueStats.error}</TableCell>
                                </>
                            )}
                        </TableRow>
                    )}
                </TableBody>
            </Table>
            <Typography variant="caption" className={classes.typographyStylesFooter}>
                Загружено: в последний запуск / за 10 минут / за сегодня
            </Typography>
        </>
    ));
};

if ((module as any).hot) {
    (module as any).hot.accept();
}

/*
    [
        {
            project: "test1",
            Pprogress: [
                { progress: 3, color: colors.orange },
                { progress: 4, color: colors.green },
                { progress: 3, color: colors.yellow },
            ],
            args: 1,
            succededJobs: 5,
            failedJobs: 100,
            runningJobs: 20,
        },
        {
            project: "test2",
            Pprogress: [
                { progress: 10, color: colors.orange },
                { progress: 20, color: colors.green },
                { progress: 60, color: colors.yellow },
            ],
            args: 2,
            succededJobs: 1,
            failedJobs: 100,
            runningJobs: 10,
        },
        {
            project: "test3",
            Pprogress: [
                { progress: 30, color: colors.orange },
                { progress: 30, color: colors.green },
                { progress: 30, color: colors.yellow },
            ],
            args: 3,
            succededJobs: 5,
            failedJobs: 50,
            runningJobs: 40,
        },
        {
            project: "test4",
            Pprogress: [
                { progress: 40, color: colors.orange },
                { progress: 30, color: colors.green },
                { progress: 10, color: colors.yellow },
            ],
            args: 4,
            succededJobs: 0,
            failedJobs: 100,
            runningJobs: 0,
        },
    ];
     */
